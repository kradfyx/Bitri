import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';
import { PrismaModule } from './modules/prisma/prisma.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { CampaignsModule } from './modules/campaigns/campaigns.module';
import { AdsModule } from './modules/ads/ads.module';
import { PublishersModule } from './modules/publishers/publishers.module';
import { WebsitesModule } from './modules/websites/websites.module';
import { PaymentsModule } from './modules/payments/payments.module';
import { InvoicesModule } from './modules/invoices/invoices.module';
import { WithdrawalsModule } from './modules/withdrawals/withdrawals.module';
import { AnalyticsModule } from './modules/analytics/analytics.module';
import { CategoriesModule } from './modules/categories/categories.module';
import { SettingsModule } from './modules/settings/settings.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { AiModule } from './modules/ai/ai.module';
import { WebhooksModule } from './modules/webhooks/webhooks.module';
import { IntegrationsModule } from './modules/integrations/integrations.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    ThrottlerModule.forRoot([
      {
        ttl: 60000,
        limit: 100,
      },
    ]),
    ScheduleModule.forRoot(),
    PrismaModule,
    AuthModule,
    UsersModule,
    CampaignsModule,
    AdsModule,
    PublishersModule,
    WebsitesModule,
    PaymentsModule,
    InvoicesModule,
    WithdrawalsModule,
    AnalyticsModule,
    CategoriesModule,
    SettingsModule,
    NotificationsModule,
    AiModule,
    WebhooksModule,
    IntegrationsModule,
  ],
})
export class AppModule {}
