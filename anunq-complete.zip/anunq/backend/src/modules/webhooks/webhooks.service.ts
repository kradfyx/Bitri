import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import axios from 'axios';

@Injectable()
export class WebhooksService {
  constructor(private prisma: PrismaService) {}

  async findAll(userId: string) {
    return this.prisma.webhook.findMany({ where: { userId } });
  }

  async create(userId: string, data: any) {
    return this.prisma.webhook.create({ data: { ...data, userId } });
  }

  async trigger(event: string, payload: any) {
    const webhooks = await this.prisma.webhook.findMany({ where: { events: { has: event }, isActive: true } });
    
    for (const webhook of webhooks) {
      try {
        await axios.post(webhook.url, { event, payload }, { headers: { 'X-Webhook-Signature': webhook.secret } });
        await this.prisma.webhook.update({ where: { id: webhook.id }, data: { lastTriggeredAt: new Date(), failureCount: 0 } });
      } catch (error) {
        await this.prisma.webhook.update({ where: { id: webhook.id }, data: { failureCount: { increment: 1 } } });
      }
    }
  }
}
