import { Controller, Get, Post, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { WebhooksService } from './webhooks.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Webhooks')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('webhooks')
export class WebhooksController {
  constructor(private webhooksService: WebhooksService) {}

  @Get()
  async findAll(@Request() req) { return this.webhooksService.findAll(req.user.id); }

  @Post()
  async create(@Request() req, @Body() data: { url: string; events: string[] }) {
    return this.webhooksService.create(req.user.id, data);
  }
}
