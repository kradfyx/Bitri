import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AdsService {
  constructor(private prisma: PrismaService) {}

  async findAll(campaignId: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({ where: { id: campaignId, userId } });
    if (!campaign) throw new NotFoundException('Campaign not found');

    return this.prisma.ad.findMany({ where: { campaignId } });
  }

  async create(campaignId: string, userId: string, data: any) {
    const campaign = await this.prisma.campaign.findFirst({ where: { id: campaignId, userId } });
    if (!campaign) throw new NotFoundException('Campaign not found');

    return this.prisma.ad.create({ data: { ...data, campaignId } });
  }

  async update(id: string, userId: string, data: any) {
    const ad = await this.prisma.ad.findFirst({
      where: { id },
      include: { campaign: true },
    });
    if (!ad || ad.campaign.userId !== userId) throw new NotFoundException('Ad not found');

    return this.prisma.ad.update({ where: { id }, data });
  }

  async delete(id: string, userId: string) {
    const ad = await this.prisma.ad.findFirst({
      where: { id },
      include: { campaign: true },
    });
    if (!ad || ad.campaign.userId !== userId) throw new NotFoundException('Ad not found');

    return this.prisma.ad.delete({ where: { id } });
  }
}
