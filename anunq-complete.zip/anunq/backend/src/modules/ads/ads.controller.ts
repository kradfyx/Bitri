import { Controller, Get, Post, Put, Delete, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AdsService } from './ads.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Ads')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('campaigns/:campaignId/ads')
export class AdsController {
  constructor(private adsService: AdsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all ads for campaign' })
  async findAll(@Request() req, @Param('campaignId') campaignId: string) {
    return this.adsService.findAll(campaignId, req.user.id);
  }

  @Post()
  @ApiOperation({ summary: 'Create new ad' })
  async create(@Request() req, @Param('campaignId') campaignId: string, @Body() data: any) {
    return this.adsService.create(campaignId, req.user.id, data);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update ad' })
  async update(@Request() req, @Param('id') id: string, @Body() data: any) {
    return this.adsService.update(id, req.user.id, data);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete ad' })
  async delete(@Request() req, @Param('id') id: string) {
    return this.adsService.delete(id, req.user.id);
  }
}
