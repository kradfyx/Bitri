import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy, VerifyCallback } from 'passport-github2';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class GitHubStrategy extends PassportStrategy(Strategy, 'github') {
  constructor(
    private configService: ConfigService,
    private prisma: PrismaService,
  ) {
    super({
      clientID: configService.get('GITHUB_CLIENT_ID'),
      clientSecret: configService.get('GITHUB_CLIENT_SECRET'),
      callbackURL: configService.get('GITHUB_CALLBACK_URL', 'http://localhost:3001/api/v1/auth/github/callback'),
      scope: ['user:email'],
    });
  }

  async validate(
    accessToken: string,
    refreshToken: string,
    profile: any,
    done: VerifyCallback,
  ): Promise<any> {
    const { id, emails, displayName, photos } = profile;

    let user = await this.prisma.user.findUnique({
      where: { oauthId: id },
    });

    if (!user) {
      const email = emails?.[0]?.value || `${id}@github.com`;
      user = await this.prisma.user.create({
        data: {
          email,
          firstName: displayName?.split(' ')[0],
          lastName: displayName?.split(' ')[1],
          avatar: photos?.[0]?.value,
          oauthProvider: 'github',
          oauthId: id,
          emailVerified: true,
          emailVerifiedAt: new Date(),
          role: 'ADVERTISER',
        },
      });
    }

    done(null, user);
  }
}
