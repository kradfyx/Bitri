import { Controller, Post, Body, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { IntegrationsService } from './integrations.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Integrations')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('integrations')
export class IntegrationsController {
  constructor(private integrationsService: IntegrationsService) {}

  @Post('stripe/connect')
  async connectStripe(@Body() body: { code: string }) {
    return this.integrationsService.connectStripe(body.code);
  }

  @Post('google-ads/connect')
  async connectGoogleAds(@Body() body: { token: string }) {
    return this.integrationsService.connectGoogleAds(body.token);
  }

  @Post('facebook-ads/connect')
  async connectFacebookAds(@Body() body: { token: string }) {
    return this.integrationsService.connectFacebookAds(body.token);
  }
}
