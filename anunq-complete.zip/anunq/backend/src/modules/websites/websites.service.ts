import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class WebsitesService {
  constructor(private prisma: PrismaService) {}

  async findAll(userId: string) {
    return this.prisma.website.findMany({ where: { userId } });
  }

  async findOne(id: string, userId: string) {
    const website = await this.prisma.website.findFirst({ where: { id, userId } });
    if (!website) throw new NotFoundException('Website not found');
    return website;
  }

  async create(userId: string, data: any) {
    const verificationCode = Math.random().toString(36).substring(2, 15);
    return this.prisma.website.create({
      data: { ...data, userId, verificationCode },
    });
  }

  async verify(id: string, userId: string, code: string) {
    const website = await this.prisma.website.findFirst({ where: { id, userId } });
    if (!website) throw new NotFoundException('Website not found');
    
    if (website.verificationCode === code) {
      return this.prisma.website.update({
        where: { id },
        data: { verificationStatus: 'VERIFIED', verifiedAt: new Date() },
      });
    }
    throw new BadRequestException('Invalid verification code');
  }

  async update(id: string, userId: string, data: any) {
    const website = await this.prisma.website.findFirst({ where: { id, userId } });
    if (!website) throw new NotFoundException('Website not found');
    return this.prisma.website.update({ where: { id }, data });
  }

  async delete(id: string, userId: string) {
    const website = await this.prisma.website.findFirst({ where: { id, userId } });
    if (!website) throw new NotFoundException('Website not found');
    return this.prisma.website.delete({ where: { id } });
  }

  async getStats(id: string, userId: string) {
    const website = await this.prisma.website.findFirst({ where: { id, userId } });
    if (!website) throw new NotFoundException('Website not found');

    const [clicks, impressions] = await Promise.all([
      this.prisma.click.count({ where: { websiteId: id } }),
      this.prisma.impression.count({ where: { websiteId: id } }),
    ]);

    const ctr = impressions > 0 ? (clicks / impressions) * 100 : 0;
    const cpm = impressions > 0 ? (website.totalEarnings / impressions) * 1000 : 0;
    const cpc = clicks > 0 ? website.totalEarnings / clicks : 0;

    return { clicks, impressions, ctr: ctr.toFixed(2), cpm: cpm.toFixed(4), cpc: cpc.toFixed(4), earnings: website.totalEarnings };
  }
}
