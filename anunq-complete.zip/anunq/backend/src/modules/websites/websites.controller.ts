import { Controller, Get, Post, Put, Delete, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { WebsitesService } from './websites.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Websites')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('websites')
export class WebsitesController {
  constructor(private websitesService: WebsitesService) {}

  @Get()
  @ApiOperation({ summary: 'Get all user websites' })
  async findAll(@Request() req) {
    return this.websitesService.findAll(req.user.id);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get website by ID' })
  async findOne(@Request() req, @Param('id') id: string) {
    return this.websitesService.findOne(id, req.user.id);
  }

  @Post()
  @ApiOperation({ summary: 'Register new website' })
  async create(@Request() req, @Body() data: any) {
    return this.websitesService.create(req.user.id, data);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update website' })
  async update(@Request() req, @Param('id') id: string, @Body() data: any) {
    return this.websitesService.update(id, req.user.id, data);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete website' })
  async delete(@Request() req, @Param('id') id: string) {
    return this.websitesService.delete(id, req.user.id);
  }

  @Post(':id/verify')
  @ApiOperation({ summary: 'Verify website ownership' })
  async verify(@Request() req, @Param('id') id: string, @Body() body: { code: string }) {
    return this.websitesService.verify(id, req.user.id, body.code);
  }

  @Get(':id/stats')
  @ApiOperation({ summary: 'Get website statistics' })
  async getStats(@Request() req, @Param('id') id: string) {
    return this.websitesService.getStats(id, req.user.id);
  }
}
