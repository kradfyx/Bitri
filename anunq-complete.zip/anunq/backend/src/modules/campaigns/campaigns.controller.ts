import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { CampaignsService } from './campaigns.service';
import { CreateCampaignDto, UpdateCampaignDto, CampaignStatusDto } from './dto/campaign.dto';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Campaigns')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('campaigns')
export class CampaignsController {
  constructor(private campaignsService: CampaignsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all campaigns for user' })
  async findAll(@Request() req, @Query() query: any) {
    return this.campaignsService.findAll(req.user.id, query);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get campaign by ID' })
  async findOne(@Request() req, @Param('id') id: string) {
    return this.campaignsService.findOne(id, req.user.id);
  }

  @Post()
  @ApiOperation({ summary: 'Create new campaign' })
  async create(@Request() req, @Body() createCampaignDto: CreateCampaignDto) {
    return this.campaignsService.create(req.user.id, createCampaignDto);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update campaign' })
  async update(
    @Request() req,
    @Param('id') id: string,
    @Body() updateCampaignDto: UpdateCampaignDto,
  ) {
    return this.campaignsService.update(id, req.user.id, updateCampaignDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete campaign' })
  async delete(@Request() req, @Param('id') id: string) {
    return this.campaignsService.delete(id, req.user.id);
  }

  @Put(':id/status')
  @ApiOperation({ summary: 'Update campaign status' })
  async updateStatus(
    @Request() req,
    @Param('id') id: string,
    @Body() statusDto: CampaignStatusDto,
  ) {
    return this.campaignsService.updateStatus(id, req.user.id, statusDto.status);
  }

  @Post(':id/duplicate')
  @ApiOperation({ summary: 'Duplicate campaign' })
  async duplicate(@Request() req, @Param('id') id: string) {
    return this.campaignsService.duplicate(id, req.user.id);
  }

  @Get(':id/stats')
  @ApiOperation({ summary: 'Get campaign statistics' })
  async getStats(@Request() req, @Param('id') id: string, @Query() query: any) {
    return this.campaignsService.getStatistics(id, req.user.id, query);
  }
}
