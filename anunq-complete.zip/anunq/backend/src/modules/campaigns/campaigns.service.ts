import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCampaignDto, UpdateCampaignDto } from './dto/campaign.dto';

@Injectable()
export class CampaignsService {
  constructor(private prisma: PrismaService) {}

  async findAll(userId: string, query: any) {
    const { status, page = 1, limit = 10, search } = query;

    const where: any = { userId };

    if (status) {
      where.status = status;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    const take = Number(limit);

    const [campaigns, total] = await Promise.all([
      this.prisma.campaign.findMany({
        where,
        skip,
        take,
        orderBy: { createdAt: 'desc' },
        include: {
          ads: {
            select: {
              id: true,
              title: true,
              adType: true,
              impressions: true,
              clicks: true,
              ctr: true,
            },
          },
          _count: {
            select: {
              clicks: true,
              impressions: true,
              conversions: true,
            },
          },
        },
      }),
      this.prisma.campaign.count({ where }),
    ]);

    return {
      data: campaigns,
      total,
      page: Number(page),
      limit: Number(limit),
      totalPages: Math.ceil(total / Number(limit)),
    };
  }

  async findOne(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, userId },
      include: {
        ads: true,
        clicks: {
          take: 100,
          orderBy: { timestamp: 'desc' },
        },
        impressions: {
          take: 100,
          orderBy: { timestamp: 'desc' },
        },
        conversions: true,
      },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    return campaign;
  }

  async create(userId: string, createCampaignDto: CreateCampaignDto) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });

    if (!user || user.balance < createCampaignDto.budget) {
      throw new BadRequestException('Insufficient balance for campaign budget');
    }

    const campaign = await this.prisma.campaign.create({
      data: {
        ...createCampaignDto,
        userId,
        status: 'PENDING_APPROVAL',
        countries: createCampaignDto.countries || [],
        states: createCampaignDto.states || [],
        cities: createCampaignDto.cities || [],
        languages: createCampaignDto.languages || [],
        deviceTypes: createCampaignDto.deviceTypes || [],
        operatingSystems: createCampaignDto.operatingSystems || [],
        browsers: createCampaignDto.browsers || [],
        scheduleDays: createCampaignDto.scheduleDays || [0, 1, 2, 3, 4, 5, 6],
        scheduleHours: createCampaignDto.scheduleHours || Array.from({ length: 24 }, (_, i) => i),
      },
    });

    // Deduct budget from user balance
    await this.prisma.user.update({
      where: { id: userId },
      data: { balance: { decrement: createCampaignDto.budget } },
    });

    return campaign;
  }

  async update(id: string, userId: string, updateCampaignDto: UpdateCampaignDto) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    if (campaign.status === 'ACTIVE') {
      throw new BadRequestException('Cannot update active campaign');
    }

    return this.prisma.campaign.update({
      where: { id },
      data: updateCampaignDto,
    });
  }

  async delete(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    if (campaign.status === 'ACTIVE') {
      throw new BadRequestException('Cannot delete active campaign');
    }

    // Refund remaining budget
    const remainingBudget = campaign.budget - campaign.spent;
    if (remainingBudget > 0) {
      await this.prisma.user.update({
        where: { id: userId },
        data: { balance: { increment: remainingBudget } },
      });
    }

    return this.prisma.campaign.delete({ where: { id } });
  }

  async updateStatus(id: string, userId: string, status: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    const validTransitions: Record<string, string[]> = {
      DRAFT: ['PENDING_APPROVAL', 'ACTIVE'],
      PENDING_APPROVAL: ['DRAFT', 'ACTIVE', 'REJECTED'],
      ACTIVE: ['PAUSED'],
      PAUSED: ['ACTIVE'],
      REJECTED: ['DRAFT', 'PENDING_APPROVAL'],
    };

    if (!validTransitions[campaign.status]?.includes(status)) {
      throw new BadRequestException(`Invalid status transition from ${campaign.status} to ${status}`);
    }

    const updateData: any = { status };

    if (status === 'ACTIVE') {
      updateData.approvedAt = new Date();
    }

    if (status === 'PAUSED') {
      // Refund unused budget for paused campaigns
      const dailyBudget = campaign.budget / 30; // Assuming 30 days
      const unusedBudget = dailyBudget * 0.5; // Refund 50% of daily budget
      await this.prisma.user.update({
        where: { id: userId },
        data: { balance: { increment: unusedBudget } },
      });
    }

    return this.prisma.campaign.update({
      where: { id },
      data: updateData,
    });
  }

  async duplicate(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, userId },
      include: { ads: true },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    const { id: _, ...data } = campaign;
    
    const newCampaign = await this.prisma.campaign.create({
      data: {
        ...data,
        name: `${campaign.name} (Copy)`,
        status: 'DRAFT',
        spent: 0,
        createdAt: undefined,
        updatedAt: undefined,
        approvedAt: null,
        approvedBy: null,
        rejectedAt: null,
        rejectedReason: null,
      },
    });

    // Duplicate ads
    for (const ad of campaign.ads) {
      const { id: adId, campaignId, ...adData } = ad;
      await this.prisma.ad.create({
        data: {
          ...adData,
          campaignId: newCampaign.id,
          impressions: 0,
          clicks: 0,
          conversions: 0,
          ctr: 0,
        },
      });
    }

    return newCampaign;
  }

  async getStatistics(id: string, userId: string, query: any) {
    const { startDate, endDate } = query;

    const campaign = await this.prisma.campaign.findFirst({
      where: { id, userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    const dateFilter: any = {};
    if (startDate && endDate) {
      dateFilter.timestamp = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    const [clicks, impressions, conversions] = await Promise.all([
      this.prisma.click.count({
        where: { campaignId: id, ...dateFilter },
      }),
      this.prisma.impression.count({
        where: { campaignId: id, ...dateFilter },
      }),
      this.prisma.conversion.count({
        where: { campaignId: id, ...dateFilter },
      }),
    ]);

    const ctr = impressions > 0 ? (clicks / impressions) * 100 : 0;
    const cpc = clicks > 0 ? campaign.spent / clicks : 0;
    const cpm = impressions > 0 ? (campaign.spent / impressions) * 1000 : 0;

    return {
      campaignId: id,
      impressions,
      clicks,
      conversions,
      ctr: ctr.toFixed(2),
      cpc: cpc.toFixed(4),
      cpm: cpm.toFixed(4),
      spent: campaign.spent,
      budget: campaign.budget,
      remaining: campaign.budget - campaign.spent,
    };
  }
}
