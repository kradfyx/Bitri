import { IsString, IsNumber, IsOptional, IsArray, IsBoolean, IsDateString, Min, ValidateNested } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateCampaignDto {
  @ApiProperty({ example: 'Summer Sale Campaign' })
  @IsString()
  name: string;

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ example: 1000 })
  @IsNumber()
  @Min(0)
  budget: number;

  @ApiProperty({ example: 'LIFETIME', enum: ['HOUR', 'DAY', 'WEEK', 'MONTH', 'LIFETIME'] })
  @IsString()
  @IsOptional()
  budgetType?: string;

  @ApiProperty({ example: 0.5 })
  @IsNumber()
  @Min(0)
  bidAmount: number;

  @ApiProperty({ example: 'CPC', enum: ['CPC', 'CPM', 'CPA'] })
  @IsString()
  bidType: string;

  @ApiProperty({ example: '2024-01-01T00:00:00Z' })
  @IsDateString()
  startDate: Date;

  @ApiProperty({ required: false })
  @IsDateString()
  @IsOptional()
  endDate?: Date;

  @ApiProperty({ example: 'https://example.com/landing' })
  @IsString()
  targetUrl: string;

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  conversionPixel?: string;

  @ApiProperty({ required: false })
  @IsBoolean()
  @IsOptional()
  isRemarketing?: boolean;

  @ApiProperty({ required: false })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  countries?: string[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  states?: string[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  cities?: string[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  languages?: string[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  categoryIds?: string[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  deviceTypes?: string[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  operatingSystems?: string[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  browsers?: string[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsNumber({}, { each: true })
  @IsOptional()
  scheduleDays?: number[];

  @ApiProperty({ required: false })
  @IsArray()
  @IsNumber({}, { each: true })
  @IsOptional()
  scheduleHours?: number[];

  @ApiProperty({ required: false })
  @IsBoolean()
  @IsOptional()
  aiOptimized?: boolean;
}

export class UpdateCampaignDto {
  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ required: false })
  @IsNumber()
  @Min(0)
  @IsOptional()
  budget?: number;

  @ApiProperty({ required: false })
  @IsNumber()
  @Min(0)
  @IsOptional()
  bidAmount?: number;

  @ApiProperty({ required: false })
  @IsDateString()
  @IsOptional()
  endDate?: Date;

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  targetUrl?: string;

  @ApiProperty({ required: false })
  @IsBoolean()
  @IsOptional()
  isRemarketing?: boolean;
}

export class CampaignStatusDto {
  @ApiProperty({ enum: ['DRAFT', 'PENDING_APPROVAL', 'ACTIVE', 'PAUSED', 'REJECTED'] })
  @IsString()
  status: string;
}
