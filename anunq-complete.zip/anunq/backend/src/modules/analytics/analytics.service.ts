import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AnalyticsService {
  constructor(private prisma: PrismaService) {}

  async getDashboard(userId: string, role: string) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    if (role === 'PUBLISHER') {
      const [todayRevenue, monthRevenue, clicks, impressions] = await Promise.all([
        this.prisma.click.aggregate({ where: { userId, timestamp: { gte: today } }, _sum: { revenue: true } }),
        this.prisma.click.aggregate({ where: { userId, timestamp: { gte: startOfMonth } }, _sum: { revenue: true } }),
        this.prisma.click.count({ where: { userId } }),
        this.prisma.impression.count({ where: { userId } }),
      ]);

      const activeWebsites = await this.prisma.website.count({ where: { userId, isApproved: true, isActive: true } });

      return {
        revenueToday: todayRevenue._sum.revenue || 0,
        revenueMonth: monthRevenue._sum.revenue || 0,
        clicks,
        impressions,
        ctr: impressions > 0 ? ((clicks / impressions) * 100).toFixed(2) : 0,
        activeWebsites,
      };
    } else {
      const campaigns = await this.prisma.campaign.findMany({ where: { userId } });
      const campaignIds = campaigns.map(c => c.id);

      const [spent, clicks, impressions, conversions] = await Promise.all([
        this.prisma.campaign.aggregate({ where: { id: { in: campaignIds } }, _sum: { spent: true } }),
        this.prisma.click.count({ where: { campaignId: { in: campaignIds } } }),
        this.prisma.impression.count({ where: { campaignId: { in: campaignIds } } }),
        this.prisma.conversion.count({ where: { campaignId: { in: campaignIds } } }),
      ]);

      const activeCampaigns = await this.prisma.campaign.count({ where: { userId, status: 'ACTIVE' } });

      return {
        spent: spent._sum.spent || 0,
        clicks,
        impressions,
        conversions,
        ctr: impressions > 0 ? ((clicks / impressions) * 100).toFixed(2) : 0,
        activeCampaigns,
      };
    }
  }

  async getReports(userId: string, type: string, startDate: Date, endDate: Date) {
    const dateFilter = { timestamp: { gte: startDate, lte: endDate } };
    
    if (type === 'campaigns') {
      return this.prisma.campaign.findMany({
        where: { userId, createdAt: { gte: startDate, lte: endDate } },
        include: { _count: { select: { clicks: true, impressions: true, conversions: true } } },
      });
    } else if (type === 'websites') {
      return this.prisma.website.findMany({
        where: { userId, createdAt: { gte: startDate, lte: endDate } },
        include: { _count: { select: { clicks: true, impressions: true } } },
      });
    }

    return [];
  }
}
