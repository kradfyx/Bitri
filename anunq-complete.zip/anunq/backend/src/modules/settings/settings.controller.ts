import { Controller, Get, Put, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { SettingsService } from './settings.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Settings')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('settings')
export class SettingsController {
  constructor(private settingsService: SettingsService) {}

  @Get()
  async findAll() { return this.settingsService.findAll(); }

  @Put(':key')
  async update(@Param('key') key: string, @Body() body: { value: any }) {
    return this.settingsService.update(key, body.value);
  }
}
