import { Controller, Get, Post, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { PaymentsService } from './payments.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Payments')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('payments')
export class PaymentsController {
  constructor(private paymentsService: PaymentsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all user payments' })
  async findAll(@Request() req) {
    return this.paymentsService.findAll(req.user.id);
  }

  @Post('stripe-intent')
  @ApiOperation({ summary: 'Create Stripe payment intent' })
  async createStripeIntent(@Request() req, @Body() body: { amount: number; currency?: string }) {
    return this.paymentsService.createStripeIntent(req.user.id, body.amount, body.currency);
  }

  @Post('pix')
  @ApiOperation({ summary: 'Create PIX payment' })
  async createPix(@Request() req, @Body() body: { amount: number }) {
    return this.paymentsService.createPixPayment(req.user.id, body.amount);
  }

  @Post(':id/confirm')
  @ApiOperation({ summary: 'Confirm payment' })
  async confirm(@Param('id') id: string, @Body() body: { transactionId: string }) {
    return this.paymentsService.confirmPayment(id, body.transactionId);
  }

  @Get('dashboard')
  @ApiOperation({ summary: 'Get payment dashboard' })
  async getDashboard(@Request() req) {
    return this.paymentsService.getDashboard(req.user.id);
  }
}
