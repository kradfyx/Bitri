import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import Stripe from 'stripe';

@Injectable()
export class PaymentsService {
  private stripe: Stripe;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.stripe = new Stripe(configService.get('STRIPE_SECRET_KEY', ''), { apiVersion: '2024-01-01' });
  }

  async findAll(userId: string) {
    return this.prisma.payment.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  }

  async createStripeIntent(userId: string, amount: number, currency: string = 'USD') {
    const intent = await this.stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency: currency.toLowerCase(),
      metadata: { userId },
    });

    const payment = await this.prisma.payment.create({
      data: {
        userId,
        amount,
        currency,
        method: 'STRIPE',
        status: 'PENDING',
        transactionId: intent.id,
      },
    });

    return { clientSecret: intent.client_secret, paymentId: payment.id };
  }

  async confirmPayment(paymentId: string, transactionId: string) {
    const payment = await this.prisma.payment.update({
      where: { id: paymentId },
      data: { status: 'COMPLETED', transactionId, processedAt: new Date() },
    });

    await this.prisma.user.update({
      where: { id: payment.userId },
      data: { balance: { increment: payment.amount } },
    });

    return payment;
  }

  async createPixPayment(userId: string, amount: number) {
    // Implement PIX integration with Mercado Pago or other provider
    const payment = await this.prisma.payment.create({
      data: {
        userId,
        amount,
        currency: 'BRL',
        method: 'PIX',
        status: 'PENDING',
      },
    });

    // Return PIX code (implementation depends on payment provider)
    return { paymentId: payment.id, pixCode: 'PIX_CODE_PLACEHOLDER' };
  }

  async getDashboard(userId: string) {
    const [totalPayments, pendingPayments, completedPayments] = await Promise.all([
      this.prisma.payment.aggregate({ where: { userId }, _sum: { amount: true } }),
      this.prisma.payment.count({ where: { userId, status: 'PENDING' } }),
      this.prisma.payment.count({ where: { userId, status: 'COMPLETED' } }),
    ]);

    return {
      totalPaid: totalPayments._sum.amount || 0,
      pendingCount: pendingPayments,
      completedCount: completedPayments,
    };
  }
}
