import { Controller, Get, Post, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { NotificationsService } from './notifications.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Notifications')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('notifications')
export class NotificationsController {
  constructor(private notificationsService: NotificationsService) {}

  @Get()
  async findAll(@Request() req) { return this.notificationsService.findAll(req.user.id); }

  @Post(':id/read')
  async markAsRead(@Param('id') id: string) { return this.notificationsService.markAsRead(id); }

  @Post('read-all')
  async markAllAsRead(@Request() req) { return this.notificationsService.markAllAsRead(req.user.id); }
}
