import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class WithdrawalsService {
  constructor(private prisma: PrismaService) {}

  async findAll(userId: string) {
    return this.prisma.withdrawal.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
  }

  async create(userId: string, data: any) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    
    if (user.balance < data.amount) {
      throw new BadRequestException('Insufficient balance');
    }

    const processingFee = data.amount * 0.02; // 2% fee
    const netAmount = data.amount - processingFee;

    const withdrawal = await this.prisma.withdrawal.create({
      data: {
        userId,
        amount: data.amount,
        method: data.method,
        accountDetails: data.accountDetails,
        processingFee,
        netAmount,
        status: 'PENDING',
      },
    });

    // Deduct from user balance
    await this.prisma.user.update({
      where: { id: userId },
      data: { balance: { decrement: data.amount } },
    });

    return withdrawal;
  }

  async approve(id: string, adminId: string, transactionId?: string) {
    const withdrawal = await this.prisma.withdrawal.findUnique({ where: { id } });
    if (!withdrawal) throw new NotFoundException('Withdrawal not found');

    return this.prisma.withdrawal.update({
      where: { id },
      data: {
        status: 'COMPLETED',
        processedAt: new Date(),
        processedBy: adminId,
        transactionId,
      },
    });
  }

  async reject(id: string, adminId: string, reason: string) {
    const withdrawal = await this.prisma.withdrawal.findUnique({ where: { id } });
    if (!withdrawal) throw new NotFoundException('Withdrawal not found');

    // Refund user
    await this.prisma.user.update({
      where: { id: withdrawal.userId },
      data: { balance: { increment: withdrawal.amount } },
    });

    return this.prisma.withdrawal.update({
      where: { id },
      data: {
        status: 'REJECTED',
        processedAt: new Date(),
        processedBy: adminId,
        rejectedReason: reason,
      },
    });
  }
}
