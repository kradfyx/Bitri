import { Controller, Get, Post, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { WithdrawalsService } from './withdrawals.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('Withdrawals')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('withdrawals')
export class WithdrawalsController {
  constructor(private withdrawalsService: WithdrawalsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all user withdrawals' })
  async findAll(@Request() req) {
    return this.withdrawalsService.findAll(req.user.id);
  }

  @Post()
  @ApiOperation({ summary: 'Request withdrawal' })
  async create(@Request() req, @Body() data: { amount: number; method: string; accountDetails: any }) {
    return this.withdrawalsService.create(req.user.id, data);
  }
}
