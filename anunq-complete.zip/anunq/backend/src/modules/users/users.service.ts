import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async findAll(query: any) {
    const { role, page = 1, limit = 10, search } = query;
    const where: any = {};

    if (role) {
      where.role = role;
    }

    if (search) {
      where.OR = [
        { email: { contains: search, mode: 'insensitive' } },
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    const take = Number(limit);

    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        skip,
        take,
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          role: true,
          balance: true,
          isActive: true,
          isBlocked: true,
          createdAt: true,
        },
      }),
      this.prisma.user.count({ where }),
    ]);

    return { data: users, total, page: Number(page), limit: Number(limit) };
  }

  async findOne(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      include: {
        campaigns: { select: { id: true, name: true, status: true } },
        websites: { select: { id: true, name: true, url: true } },
        payments: { select: { id: true, amount: true, status: true, createdAt: true }, take: 5 },
      },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    return user;
  }

  async update(id: string, data: any) {
    return this.prisma.user.update({
      where: { id },
      data,
    });
  }

  async blockUser(id: string, reason: string) {
    return this.prisma.user.update({
      where: { id },
      data: {
        isBlocked: true,
        blockedAt: new Date(),
        blockedReason: reason,
      },
    });
  }

  async unblockUser(id: string) {
    return this.prisma.user.update({
      where: { id },
      data: {
        isBlocked: false,
        blockedAt: null,
        blockedReason: null,
      },
    });
  }

  async getDashboard(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    const [todayRevenue, monthRevenue, totalClicks, totalImpressions] = await Promise.all([
      this.prisma.click.aggregate({
        where: { userId, timestamp: { gte: today } },
        _sum: { revenue: true },
      }),
      this.prisma.click.aggregate({
        where: { userId, timestamp: { gte: startOfMonth } },
        _sum: { revenue: true },
      }),
      this.prisma.click.count({ where: { userId } }),
      this.prisma.impression.count({ where: { userId } }),
    ]);

    const activeCampaigns = await this.prisma.campaign.count({
      where: { userId, status: 'ACTIVE' },
    });

    const activeWebsites = await this.prisma.website.count({
      where: { userId, isApproved: true, isActive: true },
    });

    const ctr = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0;
    const cpc = totalClicks > 0 ? (monthRevenue._sum.revenue || 0) / totalClicks : 0;
    const cpm = totalImpressions > 0 ? ((monthRevenue._sum.revenue || 0) / totalImpressions) * 1000 : 0;

    return {
      balance: user.balance,
      revenueToday: todayRevenue._sum.revenue || 0,
      revenueMonth: monthRevenue._sum.revenue || 0,
      clicks: totalClicks,
      impressions: totalImpressions,
      ctr: ctr.toFixed(2),
      cpc: cpc.toFixed(4),
      cpm: cpm.toFixed(4),
      activeCampaigns,
      activeWebsites,
    };
  }
}
