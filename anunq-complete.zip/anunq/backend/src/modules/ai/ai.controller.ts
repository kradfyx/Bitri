import { Controller, Post, Body, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AiService } from './ai.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('AI')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'))
@Controller('ai')
export class AiController {
  constructor(private aiService: AiService) {}

  @Post('generate-ad-copy')
  async generateAdCopy(@Body() body: { product: string; tone?: string }) {
    return this.aiService.generateAdCopy(body.product, body.tone);
  }

  @Post('optimize-budget')
  async optimizeBudget(@Body() data: any) {
    return this.aiService.optimizeBudget(data);
  }

  @Post('detect-fraud')
  async detectFraud(@Body() data: any) {
    return this.aiService.detectFraud(data);
  }
}
