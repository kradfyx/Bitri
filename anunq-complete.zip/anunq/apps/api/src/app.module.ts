import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { AuthModule } from './modules/auth/auth.module';
import { UserModule } from './modules/user/user.module';
import { CampaignModule } from './modules/campaign/campaign.module';
import { AdModule } from './modules/ad/ad.module';
import { WebsiteModule } from './modules/website/website.module';
import { PaymentModule } from './modules/payment/payment.module';
import { WithdrawalModule } from './modules/withdrawal/withdrawal.module';
import { StatsModule } from './modules/stats/stats.module';
import { AdminModule } from './modules/admin/admin.module';
import { ApiModule } from './modules/api/api.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    ThrottlerModule.forRoot([
      {
        ttl: 60000,
        limit: 100,
      },
    ]),
    AuthModule,
    UserModule,
    CampaignModule,
    AdModule,
    WebsiteModule,
    PaymentModule,
    WithdrawalModule,
    StatsModule,
    AdminModule,
    ApiModule,
  ],
})
export class AppModule {}
