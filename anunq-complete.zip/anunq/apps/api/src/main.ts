import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const configService = app.get(ConfigService);

  // Security
  app.use(helmet());
  
  // Rate Limiting
  app.use(
    rateLimit({
      windowMs: parseInt(configService.get('RATE_LIMIT_TTL') || '60') * 1000,
      max: parseInt(configService.get('RATE_LIMIT_MAX') || '100'),
      message: 'Too many requests from this IP, please try again later.',
    }),
  );

  // CORS
  app.enableCors({
    origin: configService.get('FRONTEND_URL', 'http://localhost:3000'),
    credentials: true,
  });

  // Global prefix
  app.setGlobalPrefix('api/v1');

  // Validation
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: {
        enableImplicitConversion: true,
      },
    }),
  );

  // Swagger Documentation
  const config = new DocumentBuilder()
    .setTitle('ANUNQ API')
    .setDescription('API para plataforma de publicidade online')
    .setVersion('1.0')
    .addBearerAuth()
    .addTag('auth', 'Autenticação e autorização')
    .addTag('users', 'Gerenciamento de usuários')
    .addTag('campaigns', 'Campanhas publicitárias')
    .addTag('ads', 'Anúncios')
    .addTag('websites', 'Sites de publishers')
    .addTag('payments', 'Pagamentos')
    .addTag('withdrawals', 'Saques')
    .addTag('stats', 'Estatísticas e métricas')
    .addTag('admin', 'Administração da plataforma')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('docs', app, document);

  const port = configService.get('PORT', 3333);
  await app.listen(port);
  
  console.log(`🚀 Application is running on: http://localhost:${port}`);
  console.log(`📚 Documentation available at: http://localhost:${port}/docs`);
}

bootstrap();
