import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { CampaignService } from './campaign.service';
import { AuthGuard } from '../../guards/auth.guard';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';

@ApiTags('campaigns')
@ApiBearerAuth()
@UseGuards(AuthGuard)
@Controller('campaigns')
export class CampaignController {
  constructor(private campaignService: CampaignService) {}

  @Get()
  @ApiOperation({ summary: 'List all campaigns for current user' })
  async findAll(@Request() req, @Query() query: any) {
    return this.campaignService.findAll(req.user.userId, query);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get campaign by ID' })
  async findOne(@Request() req, @Param('id') id: string) {
    return this.campaignService.findOne(id, req.user.userId);
  }

  @Post()
  @ApiOperation({ summary: 'Create new campaign' })
  async create(@Request() req, @Body() data: any) {
    return this.campaignService.create(req.user.userId, data);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update campaign' })
  async update(@Request() req, @Param('id') id: string, @Body() data: any) {
    return this.campaignService.update(id, req.user.userId, data);
  }

  @Post(':id/submit')
  @ApiOperation({ summary: 'Submit campaign for approval' })
  async submitForApproval(@Request() req, @Param('id') id: string) {
    return this.campaignService.submitForApproval(id, req.user.userId);
  }

  @Post(':id/pause')
  @ApiOperation({ summary: 'Pause active campaign' })
  async pause(@Request() req, @Param('id') id: string) {
    return this.campaignService.pause(id, req.user.userId);
  }

  @Post(':id/resume')
  @ApiOperation({ summary: 'Resume paused campaign' })
  async resume(@Request() req, @Param('id') id: string) {
    return this.campaignService.resume(id, req.user.userId);
  }

  @Post(':id/duplicate')
  @ApiOperation({ summary: 'Duplicate campaign' })
  async duplicate(@Request() req, @Param('id') id: string) {
    return this.campaignService.duplicate(id, req.user.userId);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete campaign' })
  async delete(@Request() req, @Param('id') id: string) {
    return this.campaignService.delete(id, req.user.userId);
  }

  @Get(':id/metrics')
  @ApiOperation({ summary: 'Get campaign metrics' })
  async getMetrics(@Param('id') id: string) {
    return this.campaignService.getMetrics(id);
  }
}
