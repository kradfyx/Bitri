import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class CampaignService {
  constructor(private prisma: PrismaService) {}

  async findAll(userId: string, query: any) {
    const { page = 1, limit = 10, status, search } = query;
    const skip = (Number(page) - 1) * Number(limit);

    const where: any = { advertiserId: userId };

    if (status) {
      where.status = status;
    }

    if (search) {
      where.name = { contains: search, mode: 'insensitive' };
    }

    const [campaigns, total] = await Promise.all([
      this.prisma.campaign.findMany({
        where,
        skip,
        take: Number(limit),
        include: {
          category: true,
          country: true,
          ads: {
            select: {
              id: true,
              type: true,
              title: true,
              isActive: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.campaign.count({ where }),
    ]);

    return {
      data: campaigns,
      meta: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / Number(limit)),
      },
    };
  }

  async findOne(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, advertiserId: userId },
      include: {
        category: true,
        country: true,
        state: true,
        city: true,
        ads: true,
        clicks: {
          take: 100,
          orderBy: { clickedAt: 'desc' },
        },
        impressions: {
          take: 100,
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    return campaign;
  }

  async create(userId: string, data: any) {
    // Validate budget
    if (data.budget <= 0) {
      throw new BadRequestException('Budget must be greater than zero');
    }

    // Validate dates
    const startDate = new Date(data.startDate);
    if (startDate < new Date()) {
      throw new BadRequestException('Start date must be in the future');
    }

    if (data.endDate && new Date(data.endDate) <= startDate) {
      throw new BadRequestException('End date must be after start date');
    }

    return this.prisma.campaign.create({
      data: {
        ...data,
        advertiserId: userId,
        status: 'DRAFT',
      },
    });
  }

  async update(id: string, userId: string, data: any) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, advertiserId: userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    // Cannot edit active campaigns
    if (campaign.status === 'ACTIVE') {
      throw new BadRequestException('Cannot edit active campaigns. Pause first.');
    }

    return this.prisma.campaign.update({
      where: { id },
      data,
    });
  }

  async submitForApproval(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, advertiserId: userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    // Check if has ads
    const adsCount = await this.prisma.ad.count({
      where: { campaignId: id },
    });

    if (adsCount === 0) {
      throw new BadRequestException('Campaign must have at least one ad');
    }

    return this.prisma.campaign.update({
      where: { id },
      data: { status: 'PENDING_APPROVAL' },
    });
  }

  async pause(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, advertiserId: userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    if (campaign.status !== 'ACTIVE') {
      throw new BadRequestException('Campaign is not active');
    }

    return this.prisma.campaign.update({
      where: { id },
      data: { status: 'PAUSED' },
    });
  }

  async resume(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, advertiserId: userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    if (campaign.status !== 'PAUSED') {
      throw new BadRequestException('Campaign is not paused');
    }

    return this.prisma.campaign.update({
      where: { id },
      data: { status: 'ACTIVE' },
    });
  }

  async duplicate(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, advertiserId: userId },
      include: { ads: true },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    const { id: _, ...campaignData } = campaign;
    const { id: __, ...adsData } = campaign.ads;

    // Create new campaign with ads
    return this.prisma.campaign.create({
      data: {
        ...campaignData,
        name: `${campaign.name} (Copy)`,
        status: 'DRAFT',
        ads: {
          create: adsData.map((ad) => ({
            ...ad,
            clickCount: 0,
            impressionCount: 0,
            conversionCount: 0,
          })),
        },
      },
    });
  }

  async delete(id: string, userId: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, advertiserId: userId },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    if (campaign.status === 'ACTIVE') {
      throw new BadRequestException('Cannot delete active campaign. Pause first.');
    }

    return this.prisma.campaign.delete({
      where: { id },
    });
  }

  // Admin methods
  async approve(id: string, adminId: string) {
    return this.prisma.campaign.update({
      where: { id },
      data: {
        status: 'ACTIVE',
        isApproved: true,
        approvedAt: new Date(),
        approvedBy: adminId,
      },
    });
  }

  async reject(id: string, adminId: string, reason: string) {
    return this.prisma.campaign.update({
      where: { id },
      data: {
        status: 'REJECTED',
        rejectedReason: reason,
      },
    });
  }

  async getMetrics(campaignId: string) {
    const campaign = await this.prisma.campaign.findUnique({
      where: { id: campaignId },
      include: {
        clicks: {
          select: {
            id: true,
            clickedAt: true,
            isFraud: true,
            converted: true,
            conversionValue: true,
          },
        },
        impressions: {
          select: {
            id: true,
            createdAt: true,
            isFraud: true,
            viewable: true,
          },
        },
      },
    });

    if (!campaign) {
      throw new NotFoundException('Campaign not found');
    }

    const totalClicks = campaign.clicks.filter((c) => !c.isFraud).length;
    const totalImpressions = campaign.impressions.filter((i) => !i.isFraud).length;
    const conversions = campaign.clicks.filter((c) => c.converted && !c.isFraud).length;
    const conversionValue = campaign.clicks
      .filter((c) => c.converted && !c.isFraud)
      .reduce((sum, c) => sum + (c.conversionValue?.toNumber() || 0), 0);

    const ctr = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0;
    const cpc = totalClicks > 0 ? campaign.spent.toNumber() / totalClicks : 0;
    const cpm = totalImpressions > 0 ? (campaign.spent.toNumber() / totalImpressions) * 1000 : 0;

    return {
      totalClicks,
      totalImpressions,
      conversions,
      conversionValue,
      ctr: ctr.toFixed(2),
      cpc: cpc.toFixed(4),
      cpm: cpm.toFixed(4),
      spent: campaign.spent.toNumber(),
      budget: campaign.budget.toNumber(),
      remaining: campaign.budget.toNumber() - campaign.spent.toNumber(),
    };
  }
}
