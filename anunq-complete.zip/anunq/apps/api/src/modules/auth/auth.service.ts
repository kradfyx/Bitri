import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
    private configService: ConfigService,
  ) {}

  async validateUser(email: string, password: string): Promise<any> {
    const user = await this.prisma.user.findUnique({
      where: { email },
      include: { oauthAccounts: true },
    });

    if (!user || !user.password) {
      // Check if user exists via OAuth only
      if (user && user.oauthAccounts.length > 0) {
        throw new UnauthorizedException('Please login using your connected provider');
      }
      return null;
    }

    if (user.isBlocked) {
      throw new UnauthorizedException('Account is blocked. Contact support.');
    }

    if (!user.isActive) {
      throw new UnauthorizedException('Account is not active.');
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return null;
    }

    // Update last login
    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const { password: _, ...result } = user;
    return result;
  }

  async login(user: any) {
    const payload = { 
      sub: user.id, 
      email: user.email, 
      role: user.role,
      name: user.name,
    };

    return {
      access_token: this.jwtService.sign(payload, {
        expiresIn: this.configService.get('JWT_EXPIRES_IN', '7d'),
      }),
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        avatar: user.avatar,
      },
    };
  }

  async register(email: string, password: string, name: string, role: string) {
    const existingUser = await this.prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      throw new UnauthorizedException('Email already registered');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await this.prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        role: role.toUpperCase(),
      },
    });

    const { password: _, ...result } = user;
    
    return this.login(result);
  }

  async validateOAuthUser(
    provider: string,
    providerAccountId: string,
    email: string,
    name: string,
    accessToken?: string,
    refreshToken?: string,
  ) {
    let user = await this.prisma.user.findFirst({
      where: {
        oauthAccounts: {
          some: {
            provider,
            providerAccountId,
          },
        },
      },
      include: { oauthAccounts: true },
    });

    if (!user) {
      // Check if user with email exists
      user = await this.prisma.user.findUnique({
        where: { email },
        include: { oauthAccounts: true },
      });

      if (user) {
        // Link OAuth account to existing user
        await this.prisma.oauthAccount.create({
          data: {
            userId: user.id,
            provider,
            providerAccountId,
            accessToken,
            refreshToken,
          },
        });
      } else {
        // Create new user
        user = await this.prisma.user.create({
          data: {
            email,
            name,
            role: 'ADVERTISER',
            emailVerified: true,
            oauthAccounts: {
              create: {
                provider,
                providerAccountId,
                accessToken,
                refreshToken,
              },
            },
          },
          include: { oauthAccounts: true },
        });
      }
    }

    if (user.isBlocked) {
      throw new UnauthorizedException('Account is blocked. Contact support.');
    }

    if (!user.isActive) {
      throw new UnauthorizedException('Account is not active.');
    }

    const { oauthAccounts, ...result } = user;
    return this.login(result);
  }

  async getProfile(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        campaigns: {
          select: {
            id: true,
            name: true,
            status: true,
            spent: true,
            totalClicks: true,
            totalImpressions: true,
          },
        },
        websites: {
          select: {
            id: true,
            name: true,
            url: true,
            isVerified: true,
            isActive: true,
            totalEarnings: true,
          },
        },
        payments: {
          take: 5,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            amount: true,
            status: true,
            method: true,
            createdAt: true,
          },
        },
      },
    });

    if (!user) {
      return null;
    }

    const { password, ...result } = user;
    return result;
  }
}
