import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { UserService } from './user.service';
import { AuthGuard } from '../../guards/auth.guard';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';

@ApiTags('users')
@ApiBearerAuth()
@UseGuards(AuthGuard)
@Controller('users')
export class UserController {
  constructor(private userService: UserService) {}

  @Get()
  @ApiOperation({ summary: 'List all users (Admin only)' })
  async findAll(@Query() query: any) {
    return this.userService.findAll(query);
  }

  @Get('me')
  @ApiOperation({ summary: 'Get current user profile' })
  async getProfile(@Request() req) {
    return this.userService.findOne(req.user.userId);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get user by ID' })
  async findOne(@Param('id') id: string) {
    return this.userService.findOne(id);
  }

  @Patch('me')
  @ApiOperation({ summary: 'Update current user profile' })
  async updateProfile(@Request() req, @Body() data: any) {
    return this.userService.update(req.user.userId, data);
  }

  @Post(':id/balance')
  @ApiOperation({ summary: 'Add balance to user (Admin only)' })
  async addBalance(@Param('id') id: string, @Body() body: { amount: number }) {
    return this.userService.addBalance(id, body.amount);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Deactivate user (Admin only)' })
  async delete(@Param('id') id: string) {
    return this.userService.delete(id);
  }
}
