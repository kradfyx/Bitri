import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class UserService {
  constructor(private prisma: PrismaService) {}

  async findAll(query: any) {
    const { page = 1, limit = 10, search, role } = query;
    const skip = (Number(page) - 1) * Number(limit);

    const where: any = {};

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (role) {
      where.role = role;
    }

    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        skip,
        take: Number(limit),
        select: {
          id: true,
          email: true,
          name: true,
          role: true,
          avatar: true,
          balance: true,
          isActive: true,
          isBlocked: true,
          createdAt: true,
        },
      }),
      this.prisma.user.count({ where }),
    ]);

    return {
      data: users,
      meta: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / Number(limit)),
      },
    };
  }

  async findOne(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      include: {
        campaigns: {
          select: {
            id: true,
            name: true,
            status: true,
            spent: true,
            totalClicks: true,
            totalImpressions: true,
            createdAt: true,
          },
        },
        websites: {
          select: {
            id: true,
            name: true,
            url: true,
            isVerified: true,
            isActive: true,
            totalEarnings: true,
            pendingEarnings: true,
          },
        },
        payments: {
          take: 10,
          orderBy: { createdAt: 'desc' },
        },
        withdrawals: {
          take: 10,
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const { password, ...result } = user;
    return result;
  }

  async update(id: string, data: any) {
    const allowedFields = ['name', 'avatar', 'timezone', 'language'];
    const filteredData: any = {};

    allowedFields.forEach((field) => {
      if (data[field] !== undefined) {
        filteredData[field] = data[field];
      }
    });

    return this.prisma.user.update({
      where: { id },
      data: filteredData,
    });
  }

  async blockUser(id: string, reason: string) {
    return this.prisma.user.update({
      where: { id },
      data: {
        isBlocked: true,
        blockedAt: new Date(),
        blockedReason: reason,
      },
    });
  }

  async unblockUser(id: string) {
    return this.prisma.user.update({
      where: { id },
      data: {
        isBlocked: false,
        blockedAt: null,
        blockedReason: null,
      },
    });
  }

  async addBalance(id: string, amount: number) {
    if (amount <= 0) {
      throw new BadRequestException('Amount must be positive');
    }

    return this.prisma.user.update({
      where: { id },
      data: {
        balance: {
          increment: amount,
        },
      },
    });
  }

  async deductBalance(id: string, amount: number) {
    if (amount <= 0) {
      throw new BadRequestException('Amount must be positive');
    }

    const user = await this.prisma.user.findUnique({ where: { id } });

    if (!user || user.balance.toNumber() < amount) {
      throw new BadRequestException('Insufficient balance');
    }

    return this.prisma.user.update({
      where: { id },
      data: {
        balance: {
          decrement: amount,
        },
      },
    });
  }

  async delete(id: string) {
    // Soft delete by deactivating
    return this.prisma.user.update({
      where: { id },
      data: { isActive: false },
    });
  }
}
