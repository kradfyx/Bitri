# ANUNQ - Advertising Platform

ANUNQ é uma plataforma completa de publicidade online que conecta anunciantes e publishers.

## 🚀 Funcionalidades

### Para Anunciantes
- Criar e gerenciar campanhas publicitárias
- Segmentação avançada (país, cidade, dispositivo, navegador, OS)
- Upload de banners e criação de anúncios
- Orçamento flexível (CPC, CPM, CPA)
- Relatórios detalhados em tempo real
- IA para otimização automática de campanhas
- Pixel de conversão e remarketing

### Para Publishers
- Cadastro de sites para monetização
- Verificação de propriedade
- Múltiplos formatos de anúncio
- Saques via PIX, transferência bancária
- Dashboard com estatísticas

### Para Administradores
- Aprovação de campanhas e sites
- Gerenciamento de usuários
- Controle de categorias
- Estatísticas globais da plataforma
- Gerenciamento de pagamentos e saques

## 🛠️ Tecnologias

### Backend
- **NestJS** - Framework Node.js
- **Prisma ORM** - Database ORM
- **PostgreSQL** - Banco de dados
- **Redis** - Cache e sessões
- **RabbitMQ** - Message queue

### Frontend
- **Next.js 14** - React framework
- **TypeScript** - Type safety
- **TailwindCSS** - Estilização
- **React Query** - Data fetching

### Infraestrutura
- **Docker** - Containerização
- **Nginx** - Reverse proxy
- **Cloudflare** - CDN e segurança
- **AWS S3** - Armazenamento de arquivos

## 📁 Estrutura do Projeto

```
anunq/
├── backend/                 # API NestJS
│   ├── src/
│   │   ├── modules/        # Módulos da aplicação
│   │   │   ├── auth/       # Autenticação
│   │   │   ├── users/      # Usuários
│   │   │   ├── campaigns/  # Campanhas
│   │   │   ├── ads/        # Anúncios
│   │   │   ├── websites/   # Sites (publishers)
│   │   │   ├── payments/   # Pagamentos
│   │   │   └── ...
│   │   ├── common/         # Utilitários comuns
│   │   └── config/         # Configurações
│   ├── prisma/             # Schema e migrations
│   └── package.json
├── frontend/               # Next.js App
└── infra/                  # Docker e configs
```

## 🔧 Instalação

### Pré-requisitos
- Node.js 18+
- PostgreSQL 14+
- Redis 7+
- RabbitMQ 3.11+

### Backend

```bash
cd backend

# Instalar dependências
npm install

# Copiar variáveis de ambiente
cp .env.example .env

# Configurar banco de dados no .env
# DATABASE_URL="postgresql://..."

# Gerar Prisma Client
npx prisma generate

# Rodar migrações
npx prisma migrate dev

# Iniciar servidor
npm run start:dev
```

A API estará disponível em `http://localhost:3001`
Documentação Swagger em `http://localhost:3001/api/docs`

### Frontend

```bash
cd frontend

# Instalar dependências
npm install

# Copiar variáveis de ambiente
cp .env.example .env.local

# Iniciar desenvolvimento
npm run dev
```

O frontend estará disponível em `http://localhost:3000`

## 📊 Endpoints da API

### Autenticação
- `POST /api/v1/auth/register` - Registrar usuário
- `POST /api/v1/auth/login` - Login
- `GET /api/v1/auth/google` - OAuth Google
- `GET /api/v1/auth/github` - OAuth GitHub

### Campanhas
- `GET /api/v1/campaigns` - Listar campanhas
- `POST /api/v1/campaigns` - Criar campanha
- `PUT /api/v1/campaigns/:id` - Atualizar campanha
- `DELETE /api/v1/campaigns/:id` - Deletar campanha

### Anúncios
- `GET /api/v1/campaigns/:campaignId/ads` - Listar anúncios
- `POST /api/v1/campaigns/:campaignId/ads` - Criar anúncio

### Websites
- `GET /api/v1/websites` - Listar websites
- `POST /api/v1/websites` - Registrar website
- `POST /api/v1/websites/:id/verify` - Verificar website

### Pagamentos
- `GET /api/v1/payments` - Histórico de pagamentos
- `POST /api/v1/payments/stripe-intent` - Criar pagamento Stripe
- `POST /api/v1/withdrawals` - Solicitar saque

### Analytics
- `GET /api/v1/analytics/dashboard` - Dashboard analytics
- `GET /api/v1/analytics/reports` - Relatórios

## 🔐 Segurança

- JWT para autenticação
- 2FA (Google Authenticator)
- Rate limiting
- Helmet.js headers
- Validação de inputs com class-validator
- Hash de senhas com bcrypt

## 🤖 Recursos de IA

- Geração automática de copy para anúncios
- Otimização de orçamento baseada em histórico
- Detecção de cliques fraudulentos
- Recomendação de bidding

## 📄 Licença

MIT License - ver [LICENSE](LICENSE) para detalhes.

## 👥 Contribuição

Contribuições são bem-vindas! Por favor, leia as diretrizes de contribuição antes de enviar PRs.
